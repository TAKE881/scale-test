// import React from "react";
// import QuizPage from "@/components/QuizPage"; // `@/components/` からインポート

// export default function QuizIndex() {
//   return <QuizPage />;
// }
