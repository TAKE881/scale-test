import React from "react";
import QuizPage from "@/components/QuizPage"; // ✅ `QuizPage.js` を読み込む

export default function ScalesQuizPage() {
  return <QuizPage />; // ✅ スケールクイズ用のページ
}
